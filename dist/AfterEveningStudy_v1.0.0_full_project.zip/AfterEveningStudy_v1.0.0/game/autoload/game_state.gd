extends Node
## 全局游戏状态：数值 / 布尔标记 / 枚举状态 / 道具 / 线索 / 章节结算 / 结局判定
## 数据规格来自 f.md《开发总表》与 e.md《各章正式脚本》

signal var_changed(key: String, old_value: int, new_value: int)
signal flag_changed(key: String, value: bool)
signal item_gained(item_id: String)
signal clue_unlocked(clue_id: String)
signal state_changed(key: String, value: String)
signal sanity_crisis()

var nums: Dictionary = {}
var flags: Dictionary = {}
var states: Dictionary = {}
var inventory: Array[String] = []
var clues: Array[String] = []
var visited_nodes: Dictionary = {}
var history: Array = []              # 回想记录 [{who,text}]
var current_chapter: int = 1
var current_node: String = ""
var play_seconds: float = 0.0
var deaths: Array[String] = []       # 本周目死亡/失踪角色
var choice_log: Array = []           # 关键选择记录

# 跨周目（持久化）数据
var persistent := {
	"endings": {},        # ending_id -> 次数
	"clues_seen": [],     # 全局线索图鉴
	"cycles": 0,          # 通关轮数（对应“第109次”梗）
	"gallery": [],        # 解锁的演出/CG式画面
	"best_truth": 0,
}

# ---------------------------------------------------------------- 道具表
const ITEMS := {
	"item_record_slip": {"name": "被揉皱的违纪记录表", "desc": "纸背印着一行被擦过的名字，笔压还在。终章可证明你被“看守”过。"},
	"item_library_card": {"name": "梁野的借书卡", "desc": "卡上名字被反复描过。终章可用来把梁野从名单里拉回一次。"},
	"item_page109": {"name": "第109页残片", "desc": "边缘焦黑。背面用铅笔写着“别替我答到”。"},
	"item_admin_key": {"name": "管理员钥匙", "desc": "老秦值班室的黄铜钥匙，齿口磨圆了。开校史馆内门与广播主控柜。"},
	"item_partial_roster": {"name": "残缺补位名单", "desc": "沈禾（删除未完成）/ 林昼（待定）。撕口很新。"},
	"item_night_roster": {"name": "夜间核对名单", "desc": "凌晨两点会自己改写的一页纸。真结局硬前置之一。"},
	"item_roster_core": {"name": "核心名单页", "desc": "总名单最中间的一页，写满了同一个名字。"},
	"item_log_fragment": {"name": "许清的日志残页", "desc": "在册 / 待定 / 删除未完成 —— 术语第一次被写全。"},
	"item_fire_tape": {"name": "火灾录像带", "desc": "五年前旧楼广播室的监控。画面里有人反锁了门。"},
	"item_broadcast_register": {"name": "广播值班登记册", "desc": "沈禾、沈禾、沈禾（删除）、林昼（补）、林昼（补）……"},
	"item_lighter": {"name": "老秦的打火机", "desc": "机身有烧灼痕。毁灭路线的火种。"},
	"item_candle": {"name": "半截蜡烛", "desc": "梁野塞给你的。停电时它比手机好用。"},
	"item_seat_chart": {"name": "旧座位表", "desc": "最后一排靠窗的名字被擦了三次，纸都毛了。"},
	"item_mirror_shard": {"name": "镜片碎片", "desc": "碎片里的你，总比你慢半拍。边缘割过手。"},
}

# ---------------------------------------------------------------- 线索表
const CLUES := {
	"clue_record_table": {"name": "违纪记录表", "ch": 1, "text": "报到第一天，桌上就压着一张写着你名字的违纪记录表。日期不是今天。"},
	"clue_erased_seat": {"name": "被擦掉的座位名", "ch": 1, "text": "座位表最后一排靠窗，被反复擦过三次。周叙不许你问。"},
	"clue_missing_one": {"name": "人数不对", "ch": 1, "text": "点名结束后，许清说了一句“人数不对”。全班没有人反驳。"},
	"clue_page109": {"name": "第109页", "ch": 1, "text": "图书馆那本书的第109页被撕走了。撕口是新的，每次都是新的。"},
	"clue_dont_answer": {"name": "别替我答到", "ch": 1, "text": "残页背面的铅笔字。全作最核心的一条规则。"},
	"clue_first_rollcall": {"name": "第一次异常点名", "ch": 1, "text": "广播念到一个只有姓的名字：“沈——”。后半个音被吃掉了。"},
	"clue_knock_pattern": {"name": "门外的敲门节奏", "ch": 1, "text": "三下，停，两下。宿管从来不这么敲。"},
	"clue_headcount": {"name": "影子数不对", "ch": 3, "text": "四个人的宿舍，地上有五道影子；查寝的人却只数四下。"},
	"clue_shampoo": {"name": "劣质洗发水味", "ch": 2, "text": "廉价洗发水混着烧焦电路的味道。她出现前，总是先有味道。"},
	"clue_repeat_name": {"name": "重复的名字", "ch": 2, "text": "值班登记册上，“林昼（补）”写了很多遍，字迹一次比一次浅。"},
	"clue_terms": {"name": "名单术语", "ch": 2, "text": "在册：安全。待定：可被替换。删除未完成：还留在这里的人。"},
	"clue_shenhe_name": {"name": "沈禾的全名", "ch": 2, "text": "沈禾。五年前旧楼火灾里，唯一没有被念完名字的人。"},
	"clue_zhouxu_fill": {"name": "周叙补过名字", "ch": 3, "text": "他每次替缺席的人答“到”，都是为了让晚自习能下课。"},
	"clue_xuqing_barefoot": {"name": "许清不穿鞋", "ch": 3, "text": "她在走廊上从不穿鞋，脚底干净得不像走过路。"},
	"clue_night_rewrite": {"name": "名单会在夜里改写", "ch": 3, "text": "凌晨两点十七分，纸上的墨会自己动。你的名字后面多了“可补”。"},
	"clue_109th": {"name": "第109次", "ch": 4, "text": "录像编号 109。你在其中的每一次，都坐在最后一排靠窗。"},
	"clue_xuqing_dead": {"name": "许清早已不在", "ch": 4, "text": "五年前的教师名录里，她的名字后面写着“已故”。她只是还在描线。"},
	"clue_self_repeat": {"name": "重复的你", "ch": 4, "text": "档案里有很多个林昼。照片上的脸，一次比一次模糊。"},
	"clue_rule_gap": {"name": "规则的漏洞", "ch": 4, "text": "删除未完成者，不能由同格替补直接覆盖。他们一直在跳步骤。"},
	"clue_fire_truth": {"name": "五年前的火", "ch": 4, "text": "广播室的门从外面被反锁。点名还在继续，没有人停下。"},
}

func _ready() -> void:
	reset_run()
	set_process(true)

func _process(delta: float) -> void:
	play_seconds += delta

# ---------------------------------------------------------------- 生命周期
func reset_run() -> void:
	nums = Cfg.NUM_DEFAULT.duplicate(true)
	flags = {}
	states = Cfg.ENUM_DEFAULT.duplicate(true)
	inventory = []
	clues = []
	visited_nodes = {}
	history = []
	choice_log = []
	deaths = []
	current_chapter = 1
	current_node = ""
	play_seconds = 0.0
	# 循环继承：第二周目起，回响天然更高（“既视感”）
	var cyc: int = int(persistent.get("cycles", 0))
	if cyc > 0:
		nums["memory_echo"] = mini(3 + cyc, 8)

# ---------------------------------------------------------------- 数值
func get_num(key: String) -> int:
	return int(nums.get(key, 0))

func set_num(key: String, value: int) -> void:
	var old := get_num(key)
	var nv := Cfg.clampi_var(key, value)
	nums[key] = nv
	if nv != old:
		var_changed.emit(key, old, nv)
		if key == "sanity" and nv <= 25 and old > 25:
			sanity_crisis.emit()

func add_num(key: String, delta: int) -> void:
	set_num(key, get_num(key) + delta)

# ---------------------------------------------------------------- 标记
func get_flag(key: String) -> bool:
	return bool(flags.get(key, false))

func set_flag(key: String, value: bool = true) -> void:
	flags[key] = value
	flag_changed.emit(key, value)

# ---------------------------------------------------------------- 枚举
func get_state(key: String) -> String:
	return String(states.get(key, ""))

func set_state(key: String, value: String) -> void:
	states[key] = value
	state_changed.emit(key, value)

# ---------------------------------------------------------------- 道具与线索
func has_item(id: String) -> bool:
	return inventory.has(id)

func add_item(id: String) -> void:
	if not inventory.has(id):
		inventory.append(id)
		item_gained.emit(id)

func remove_item(id: String) -> void:
	inventory.erase(id)

func add_clue(id: String) -> void:
	if not clues.has(id):
		clues.append(id)
		clue_unlocked.emit(id)
		var seen: Array = persistent.get("clues_seen", [])
		if not seen.has(id):
			seen.append(id)
			persistent["clues_seen"] = seen

func item_name(id: String) -> String:
	return String(ITEMS.get(id, {}).get("name", id))

# ---------------------------------------------------------------- 死亡登记
func register_loss(who: String, kind: String) -> void:
	var rec := "%s:%s" % [who, kind]
	if not deaths.has(rec):
		deaths.append(rec)

# ---------------------------------------------------------------- 章节结算
## 第一章（e.md 六、第一章章节结算逻辑）
func settle_chapter_1() -> void:
	if get_flag("flag_liangye_library") and get_flag("flag_library_page109"):
		set_state("liangye_state", "fear_alive")
	elif get_num("trust_liangye") < 0 and not get_flag("flag_liangye_library"):
		set_state("liangye_state", "missing_marked")
	elif get_num("trust_liangye") >= 2:
		set_state("liangye_state", "ally_shaken")
	else:
		set_state("liangye_state", "normal")

	if get_num("trust_zhouxu") >= 2:
		set_state("zhouxu_state", "guarding")
	elif get_num("trust_zhouxu") <= -2:
		set_state("zhouxu_state", "hiding")
	else:
		set_state("zhouxu_state", "normal")

	if get_num("shenhe_focus") >= 5:
		set_state("shenhe_state", "calling")
	else:
		set_state("shenhe_state", "echo")

	if get_num("trust_xuqing") <= -2:
		set_state("xuqing_state", "suspected")
	current_chapter = 2

## 第二章（e.md 五、第二章章节结算逻辑 + f.md 状态机）
func settle_chapter_2() -> void:
	if get_flag("flag_liangye_marked") and get_num("trust_liangye") < 0:
		set_state("liangye_state", "missing_marked")
		add_item("item_library_card")
		add_num("truth", 2)
		register_loss("梁野", "被点名带走")
	elif get_flag("flag_liangye_half"):
		set_state("liangye_state", "half_assimilated")
	elif get_num("trust_liangye") >= 2:
		set_state("liangye_state", "ally_shaken")
	elif get_flag("flag_liangye_library") and get_flag("flag_library_page109"):
		set_state("liangye_state", "fear_alive")
	else:
		set_state("liangye_state", "fear_alive")

	if get_num("trust_zhouxu") >= 2:
		set_state("zhouxu_state", "guarding")
	elif get_num("trust_zhouxu") <= -2:
		set_state("zhouxu_state", "coercing")
	else:
		set_state("zhouxu_state", "hiding")

	if get_flag("flag_oldqin_burndeath"):
		set_state("oldqin_state", "burned")
		register_loss("老秦", "值班室起火")
	elif get_flag("flag_oldqin_missing"):
		set_state("oldqin_state", "missing")
		register_loss("老秦", "失踪")

	if get_num("shenhe_focus") >= 8 or get_flag("flag_first_face_to_face_shenhe"):
		set_state("shenhe_state", "half_present")
	elif get_num("shenhe_focus") >= 4:
		set_state("shenhe_state", "calling")

	if get_num("trust_xuqing") <= -3 or get_flag("flag_found_xuqing_log_fragment"):
		set_state("xuqing_state", "suspected")
	current_chapter = 3

## 第三章（e.md 五、第三章章节结算逻辑）
func settle_chapter_3() -> void:
	# 梁野
	if get_flag("flag_gave_up_roommate"):
		set_state("liangye_final_state_ch3", "abandoned")
		register_loss("梁野", "被放弃")
	elif get_flag("flag_liangye_half_assimilated"):
		set_state("liangye_final_state_ch3", "rescued_half" if get_num("trust_liangye") >= 1 else "missing")
	elif get_flag("flag_liangye_returned") and get_num("trust_liangye") >= 3:
		set_state("liangye_final_state_ch3", "anchor_alive")
	elif get_flag("flag_liangye_returned"):
		set_state("liangye_final_state_ch3", "fragile_alive")
	elif get_state("liangye_state") == "missing_marked":
		set_state("liangye_final_state_ch3", "missing")
		register_loss("梁野", "未救回")
	else:
		set_state("liangye_final_state_ch3", "fragile_alive")

	# 周叙
	if get_num("trust_zhouxu") >= 3 and get_flag("flag_zhouxu_confessed_part"):
		set_state("zhouxu_final_state_ch3", "confessor_protector")
	elif get_num("trust_zhouxu") <= -2:
		set_state("zhouxu_final_state_ch3", "coercer")
	else:
		set_state("zhouxu_final_state_ch3", "split_guard")

	# 真结局前置
	if get_flag("flag_name_written_back"):
		set_flag("true_end_precondition_1", true)
	if get_flag("flag_night_roster_taken") or has_item("item_night_roster"):
		set_flag("true_end_precondition_2", true)
	if get_flag("flag_found_xuqing_log_fragment") and get_num("truth") >= 18:
		set_flag("archive_route_bonus", true)
	current_chapter = 4

## 第四章（e.md 五、第四章章节结算逻辑）
func settle_chapter_4() -> void:
	# 真相层级
	var t := get_num("truth")
	var core := get_flag("flag_saw_fire_video") and get_flag("flag_saw_self_repeat") and get_flag("flag_rule_terms_complete")
	if t >= 25 and core and get_flag("flag_true_linday_status_known"):
		set_state("truth_state", "complete")
	elif t >= 18 and (get_flag("flag_saw_fire_video") or get_flag("flag_roster_core_taken")):
		set_state("truth_state", "high")
	else:
		set_state("truth_state", "partial")

	# 梁野终章前状态
	match get_state("liangye_final_state_ch3"):
		"anchor_alive":
			set_state("liangye_end_state", "present_anchor" if not get_flag("flag_liangye_final_loss") else "absent_echo")
		"rescued_half":
			set_state("liangye_end_state", "present_fragile_truth" if not get_flag("flag_liangye_final_loss") else "absent_echo")
		"fragile_alive":
			set_state("liangye_end_state", "present_unstable" if not get_flag("flag_liangye_final_loss") else "absent_echo")
		_:
			set_state("liangye_end_state", "absent_echo")

	# 周叙终章前状态
	match get_state("zhouxu_final_state_ch3"):
		"confessor_protector":
			set_state("zhouxu_end_state", "enter_with_player" if get_num("trust_zhouxu") >= 3 else "follow_to_threshold")
		"coercer":
			set_state("zhouxu_end_state", "pressure_player")
		_:
			set_state("zhouxu_end_state", "follow_to_threshold")

	# 终章广播改写条件
	var ready_broadcast := (has_item("item_roster_core") or has_item("item_night_roster")) \
		and (has_item("item_admin_key") or get_flag("flag_fakewall_opened")) \
		and get_num("truth") >= 18
	if ready_broadcast:
		set_flag("flag_terminal_broadcast_ready", true)
	current_chapter = 5

# ---------------------------------------------------------------- 结局判定（f.md 七 / e.md 七）
var player_chose_self_substitute := false
var player_triggered_fire_sequence := false

func can_true_end() -> bool:
	return (
		get_state("truth_state") == "complete"
		and get_flag("true_end_precondition_1")
		and get_flag("true_end_precondition_2")
		and get_num("save_route_score") >= 5
		and get_flag("flag_rule_terms_complete")
		and get_flag("flag_terminal_broadcast_ready")
		and not get_flag("flag_gave_up_roommate")
		and get_state("liangye_end_state") in ["present_anchor", "present_fragile_truth"]
	)

func can_bittersweet_exchange() -> bool:
	return (
		get_num("save_route_score") >= 4
		and get_flag("flag_terminal_broadcast_ready")
		and (
			get_state("liangye_end_state") == "absent_echo"
			or not get_flag("flag_rule_terms_complete")
			or player_chose_self_substitute
		)
	)

func can_destroyer() -> bool:
	return (
		get_num("end_cycle_score") >= 5
		and get_flag("flag_terminal_broadcast_ready")
		and player_triggered_fire_sequence
	)

func can_manager() -> bool:
	return (
		get_num("control_route_score") >= 5
		or (get_flag("flag_gave_up_roommate") and get_num("control_route_score") >= 4)
	)

func determine_ending() -> String:
	if can_true_end():
		return "ending_true_release"
	elif can_bittersweet_exchange():
		return "ending_bittersweet_exchange"
	elif can_destroyer():
		return "ending_destroyer"
	elif can_manager():
		return "ending_manager"
	return "ending_empty_seat"

func record_ending(id: String) -> void:
	var e: Dictionary = persistent.get("endings", {})
	e[id] = int(e.get(id, 0)) + 1
	persistent["endings"] = e
	persistent["cycles"] = int(persistent.get("cycles", 0)) + 1
	persistent["best_truth"] = maxi(int(persistent.get("best_truth", 0)), get_num("truth"))
	SaveSystem.save_persistent()

func unlock_gallery(id: String) -> void:
	var g: Array = persistent.get("gallery", [])
	if not g.has(id):
		g.append(id)
		persistent["gallery"] = g
		SaveSystem.save_persistent()

# ---------------------------------------------------------------- 序列化
func to_dict() -> Dictionary:
	return {
		"nums": nums.duplicate(true),
		"flags": flags.duplicate(true),
		"states": states.duplicate(true),
		"inventory": inventory.duplicate(),
		"clues": clues.duplicate(),
		"visited": visited_nodes.duplicate(true),
		"chapter": current_chapter,
		"node": current_node,
		"time": play_seconds,
		"deaths": deaths.duplicate(),
		"choice_log": choice_log.duplicate(true),
		"history": history.slice(maxi(0, history.size() - 200)),
		"self_sub": player_chose_self_substitute,
		"fire_seq": player_triggered_fire_sequence,
	}

func from_dict(d: Dictionary) -> void:
	nums = Cfg.NUM_DEFAULT.duplicate(true)
	for k in d.get("nums", {}):
		nums[k] = int(d["nums"][k])
	flags = (d.get("flags", {}) as Dictionary).duplicate(true)
	states = Cfg.ENUM_DEFAULT.duplicate(true)
	for k in d.get("states", {}):
		states[k] = String(d["states"][k])
	inventory.clear()
	for i in d.get("inventory", []):
		inventory.append(String(i))
	clues.clear()
	for c in d.get("clues", []):
		clues.append(String(c))
	visited_nodes = (d.get("visited", {}) as Dictionary).duplicate(true)
	current_chapter = int(d.get("chapter", 1))
	current_node = String(d.get("node", ""))
	play_seconds = float(d.get("time", 0.0))
	deaths.clear()
	for x in d.get("deaths", []):
		deaths.append(String(x))
	choice_log = (d.get("choice_log", []) as Array).duplicate(true)
	history = (d.get("history", []) as Array).duplicate(true)
	player_chose_self_substitute = bool(d.get("self_sub", false))
	player_triggered_fire_sequence = bool(d.get("fire_seq", false))
